//
//  FMOpenGLWindow.h
//  LearnOpenGL1(三角形)
//
//  Created by yfm on 2021/8/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FMOpenGLWindow : UIView

@end

NS_ASSUME_NONNULL_END
