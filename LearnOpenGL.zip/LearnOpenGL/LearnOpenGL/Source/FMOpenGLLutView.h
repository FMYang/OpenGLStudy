//
//  FMOpenGLLutView.h
//  LearnOpenGL
//
//  Created by yfm on 2021/9/3.
//

#import "FMOpenGLView.h"

NS_ASSUME_NONNULL_BEGIN

@interface FMOpenGLLutView : FMOpenGLView

@end

NS_ASSUME_NONNULL_END
