//
//  FMOpenGLTriangle.h
//  LearnOpenGL
//
//  Created by yfm on 2021/8/25.
//

#import <UIKit/UIKit.h>
#import "FMOpenGLView.h"

NS_ASSUME_NONNULL_BEGIN

@interface FMOpenGLTriangle : FMOpenGLView

@end

NS_ASSUME_NONNULL_END
