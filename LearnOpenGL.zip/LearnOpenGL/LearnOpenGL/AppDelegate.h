//
//  AppDelegate.h
//  LearnOpenGL
//
//  Created by yfm on 2021/8/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end

