//
//  ViewController.h
//  LearnOpenGL1(三角形)
//
//  Created by yfm on 2021/8/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

